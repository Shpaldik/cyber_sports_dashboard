<template>
    <div>
        <AdminForm />
    </div>
</template>

<script setup>
import AdminForm from '@/components/AdminForm.vue';
</script>