<template>  
    <div>
        <Header />
        <ProfileBlock />
        <Footer />
    </div>
</template>

<script setup>
import Header from '../components/Header.vue';
import ProfileBlock from '@/components/ProfileBlock.vue';
import Footer from '../components/Footer.vue';
</script>